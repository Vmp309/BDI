
class Livro:
    def __init__(self, titulo, autor, quantidade, preco, sinopse):
        self.titulo = titulo
        self.autor = autor
        self.quantidade = quantidade
        self.preco = preco
        self.sinopse = sinopse
